# -*- coding: utf-8 -*-
#!/usr/bin/env python
import pygame
import random
import easygui

easygui.msgbox("Press w to change the width of the pen. Press space bar to change pen color. Use arrow keys to control the pen. Use enter key to take a screenshot and save it. Press e to use eraser. Press space bar to resume.")

response = easygui.integerbox(title='Draw Pixel', msg="Enter the width of the pen(In pixel)")

back_color = easygui.buttonbox(title='Draw Pixel', msg='Choose a background color',
                               choices = ['Black', 'White'])
try:
    r = response
except:
    easygui.msgbox("Please enter a integer")

pygame.init()
White = 255, 255, 255
Black = 0, 0, 0
screen = pygame.display.set_mode((800, 800))
if back_color == 'White':
    screen.fill(White)
else:
    screen.fill(Black)
pygame.display.set_caption("Draw!")
finished = False
random_color = True
a = random.randint(1, 250)
b = random.randint(1, 250)
c = random.randint(1, 250)

x = 400
y = 400

while not finished:
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                        finished = True
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                        a = random.randint(1, 250)
                        b = random.randint(1, 250)
                        c = random.randint(1, 250)
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_e:
                        if back_color == 'White':
                            a = 255
                            b = 255
                            c = 255
                        else:
                            a = 0
                            b = 0
                            c = 0
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    x, y = event.pos
                elif event.type == pygame.MOUSEMOTION:
                    x, y = event.pos
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_w:
                    response = easygui.integerbox("Enter the size of the pen(In pixel)")
                    try:
                        r = response
                    except:
                        easygui.msgbox("Please enter a integer")
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_RETURN:
                    path = easygui.filesavebox()
                    pygame.image.save(screen, path)
        
        pressed = pygame.key.get_pressed()
        if pressed[pygame.K_UP]: y -= 3
        if pressed[pygame.K_DOWN]: y += 3
        if pressed[pygame.K_LEFT]: x -= 3
        if pressed[pygame.K_RIGHT]: x += 3
        
        if random_color:
            color = (a, b, c)
        if not random_color:
            color = (0, 0, 0)
            pygame.draw.rect(screen, color, pygame.Rect(x, y, 10, 10))
        try:
            pygame.draw.rect(screen, color, pygame.Rect(x, y, r, r))
        except:
            easygui.msgbox("Error")
        
        pygame.display.flip()
